In this test case, you have to fix a Java exception on this project. (2 days including install environment, if any)

Prerequisites:
* Install maven eclipse and run-jetty-run, please refer to this guide - http://books.zkoss.org/wiki/ZK_Installation_Guide/Setting_up_IDE/Maven/Setting_up_Maven_on_IDE/Setting_up_Maven_on_Eclipse
* JDK 1.5 later
* Import the mvn-no1 folder as a Eclipse project.

After you ready, please visit the page http://localhost:8080/mvn-no1/
and then click the button "Remove All", which means all of the items should be removed without any exception.