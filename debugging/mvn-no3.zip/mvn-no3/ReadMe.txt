In this test case, you have to find what's wrong in this project. (3 days including install environment, if any)

Prerequisites:
* Install maven eclipse and run-jetty-run, please refer to this guide - http://books.zkoss.org/wiki/ZK_Installation_Guide/Setting_up_IDE/Maven/Setting_up_Maven_on_IDE/Setting_up_Maven_on_Eclipse
* JDK 1.5 later
* Import the mvn-no1 folder as a Eclipse project.

After you ready, please visit the page http://localhost:8080/mvn-no3/
and then you will see some description on the page as follows.

/*****************************************/
1. You shall see two listboxes.
2. The first one is Name-0 ~ Name-4, and Name-0 is selected
3. The second one is A ~ C, and A is selected.
4. Please select Name-0 to Name-3
5. You should not see any JavaScript error, and the last listbox selects the A.
/******************************************/

Queston:
1. Please find what's wrong within the example
2. If the example cannot be modified, how to fix the error(if you are a ZK developer)?